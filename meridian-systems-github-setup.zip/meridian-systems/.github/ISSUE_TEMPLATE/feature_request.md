---
name: Feature request
about: Propose new functionality for a module
title: "[FEATURE] "
labels: type:feature
assignees: ""
---

**Module:**

**Requesting department/role:**

**Problem this solves:**

**Proposed behavior:**

**Related requirement ID (if one already exists in docs/requirements/):**

**Does this touch a shared screen/model (Job Detail, Order Detail, Record Detail)?**
<!-- If yes, tag the other modules' code owners -->
