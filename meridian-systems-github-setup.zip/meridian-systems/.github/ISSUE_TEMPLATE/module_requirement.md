---
name: Module requirement
about: Track a single requirement item through Requirements → Design → Build → Test → Done
title: "[REQ] "
labels: sdlc:requirements
assignees: ""
---

**Module:**

**Requirement ID:** <!-- e.g. REQ-FIN-009 -->

**Requirement statement:** <!-- "The system shall..." -->

**Type:** Functional / Non-Functional / Data / Integration / Business Rule

**Acceptance criteria:**

**Open questions:**

**SDLC stage:** <!-- move the `sdlc:*` label as this progresses:
sdlc:requirements → sdlc:design → sdlc:development → sdlc:testing → sdlc:done -->
