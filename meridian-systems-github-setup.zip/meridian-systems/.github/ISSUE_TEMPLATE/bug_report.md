---
name: Bug report
about: Something isn't working as specified
title: "[BUG] "
labels: type:bug
assignees: ""
---

**Module** (e.g. jobs, inventory, finance):

**Role affected** (e.g. Field Technician, Warehouse):

**What happened:**

**What you expected instead:**

**Steps to reproduce:**
1.
2.
3.

**Screenshots/logs:**

**Environment:** (staging / production, browser/device)
