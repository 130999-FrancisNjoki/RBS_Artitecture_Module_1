## Summary

<!-- What does this change do, in one or two sentences? -->

## Module(s) affected

<!-- e.g. jobs, inventory. If this touches a shared screen/model
(Job Detail, Order Detail, Record Detail), list every module that consumes it. -->

## Requirement(s) satisfied

<!-- Link the requirement ID(s) from docs/requirements/<module>.md, e.g. REQ-FT-014 -->

## Changes

<!-- Bullet list of what changed -->

## Testing

<!-- How did you verify this works? Include role-based access testing:
did you confirm users WITHOUT the right permission can't reach this? -->

## Screenshots (if UI change)

<!-- Before/after, or a link to the updated Figma frame -->

## Checklist

- [ ] Meets linked requirement's acceptance criteria
- [ ] Unit tests added/updated
- [ ] Role-based access explicitly tested
- [ ] Empty/loading/error states handled
- [ ] No secrets or customer data committed
- [ ] Relevant code owner tagged for review
